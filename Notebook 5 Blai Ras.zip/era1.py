
# Substitueix la comanda pass pel teu codi
def era1(n):
    import math
    limit = n+1 #Donat el nombre n els enters a calcular estan inclosos fins a n+1, i ha això li dic "limit"
    llistaA = [True for numero in range(limit)] #La variable LlistaA es "Veritat" (booleana) per cada i(numero) d'un rang que es el meu "limit"
    for numero in range(2, int(math.sqrt(n))): #per cada i(numero) dins d'un rang de 2 fins els enters de l'arrel quadrada del enter
        if llistaA[numero]:#Si el numero en questió...
            for x in range(numero**2, limit, numero): #Per cada x dins d'un rang del doble de numero fins al limit pasant per cada "i"(numero)...
                llistaA[x] = False #Aquest "numero" x està fora del rang perque es més gran que l'arrel quadrada de n, (es mes gran que l'arrel quadrada de n perquè l'he elevat al cuadrat) i per aixo es "False"
    llistaprimers = [] #Crea un vector buit que sigui una llista, on posaré tots el primers
    for numero in range(2, limit): #Per cada numero que em queda del 2 al limit (n+1)...
        if llistaA[numero]: #Si existeix algun numero dins de Llista A...
            llistaprimers.append(numero)#Ajuntal a la llista de primers
    return llistaprimers #Retorna'm els numeros que hi hagin dins de la llistaprimers i que per tant són primers