# Substitueix la comanda pass pel teu codi
import time
import math
def mcd(x,y):
    t1 = time.clock() #t1 es la variable que inicia el temps de rellotge del ordinador a fer una determinada tasca
    while y != 0: #Mentre la y sigui diferent de zero...:
        (x, y) = (y, x % y) #Ves calculant el mòdul de x % y.
    maxcomdiv = x #Relaciona la variable maxcomdiv a x, que es el resultat final del maxim comu divisor
    t2 = time.clock() #t2 es la variable que defineix quan deixo de "cronometrar" el temps de rellotge del ordinador 
    temps = ((t2-t1)*1000)
    return (maxcomdiv, temps)