# Substitueix la comanda pass pel teu codi
import time
import math
def fermatp(n):
    t1 = time.clock() #t1 es la variable que inicia el temps de rellotge del ordinador a fer una determinada tasca
    a= [2,3,5] #"a" es la llista dels valors primers que l'enunciat em demana d'utilitzar
    if n<=5: #Pel teorema petit de fermat, "a" sempre ha de ser més petit que el nombre a comprobar si es primer (n), per tant
    #només haig d'acceptar n més grans que 5 i provar-ho amb totes 3 "a"
        print "Ho sento, "'n'" ha de ser com a mínim més gran que 5" #missatge d'error
        return
    else:
        for i in a: #Per cada número de la llista..:
            esprimer = i**n % n == i #Un número es primer si el mòdul de dividir un enter més petit que el suposat nombre primer
            #(n) elevat a aquest suposat nombre primer és igual al enter donat, es número primer.
    t2 = time.clock()#t2 es la variable que defineix quan deixo de "cronometrar" el temps de rellotge del ordinador 
    temps = ((t2-t1)*1000)
    return (esprimer,temps)