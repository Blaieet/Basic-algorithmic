
# Substitueix la comanda pass pel teu codi
import time
def factorp(n):
    t1 = time.clock() #t1 es la variable que inicia el temps de rellotge del ordinador a fer una determinada tasca
    for i in range(2, n): #En un rang de 2 (primer número primer) fins al enter donat...:
        if n % i != 0: #Si el mòdul d'anar divint entre els números d'aquest rang és sempre diferent de zero, es que és numero
        #primer, ja que els números primers només son divisibles entre ells mateixos i 1.
            esprimer = True
        else:
            esprimer = False #Si el mòdul d'anar divint entre els números d'aquest rang és 0, es que no es primer
    t2 = time.clock()
    temps = ((t2-t1)*1000) #t2 es la variable que defineix quan deixo de "cronometrar" el temps de rellotge del ordinador 
    print (esprimer,temps)