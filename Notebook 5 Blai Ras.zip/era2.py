# Substitueix la comanda pass pel teu codi
import time
def era2(nombre):
    t1 = time.clock() #t1 es la variable que inicia el temps de rellotge del ordinador a fer una determinada tasca
    era1(nombre) #crida la funció era1 amb el paràmetre (nombre) 
    #que defineix fins a quin numero enter volem calcular quants numero primers hi ha
    t2 = time.clock() #t2 es la variable que defineix quan deixo de "cronometrar" el temps de rellotge del ordinador 
    temps_en_segons = (t2-t1) #temps es la variable que defineix la diferencia entre el final del rellotge (t2) menys 
    # l'inici del rellotge (t1)
    llistaprimers = era1(nombre) #defineixo que la variable que he usat en era1, llistaprimers, sigui la que "agafi" els valors
    #(en aquest cas els números primers) que he calculat en era1
    tantsprimers = len(llistaprimers) #calcula quants elements hi ha en llistaprimers
    return (tantsprimers,temps_en_segons)