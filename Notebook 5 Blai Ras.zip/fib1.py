# Substitueix la comanda pass pel teu codi

import time
def fib1(n):
    if n < 2: #En la seqüencia de fibonacci els dos primers termes, 0 i 1, corresponen sempre a les posicions "0" i "1"
        return n
    fibonaccin = fib1(n-2) + fib1(n-1) #Crida la funció fib1 (recursiu) calculant amb la fòrmula de fibonacci, la suma entre el
    #terme de dos posicions més enrere amb el terme de davant (n-1)
    return fibonaccin
    
#Com que es una funció recursiva, el format de temps "estàndar" no el puc fer servir, aixi que creo una altre funció, fib1temps,
#que l'únic que em fa es calcularme el temps de la funció que vull calcular, fib1
    
def fib1temps(n):
    t1 = time.clock() 
    fibonaccin = fib1(n) #Crido la funció fib1 que és la qual vull calcular el seu temps
    t2 = time.clock()
    temps = ((t2-t1)*1000)
    return (fibonaccin, temps)