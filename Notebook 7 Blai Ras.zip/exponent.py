# Substitueix la comanda pass pel teu codi

import math #Agafa la llibreria math, ja que utilitzarem la funció math.floor
def exponent(a,b):
    if b == 0: #Qualsevol base elevada a 0 és 1
        return 1
    z = exponent(a, math.floor(b/2)) #Anomeno "z" al resultat de cridar recursivament la funció exponent amb l'exponent
    #divit entre dos arrodonit "cap abaix". 

    
    if b % 2 == 0: #Si l'exponent és múltiple de 2...:
        return z**2 #Eleva el resultat de la crida recursiva a 2, ja que a^n=a⌊n/2⌋⋅a⌈n/2⌉
    
    else: #Si l'exponent no és múltiple de dos...:
        return a * (z**2) #Realitza la base pel resultat de la crida recursiva al quadrat, d'aquesta manera la crida recursiva
    # em serveix tambè per exponents que "primerament" no són divisibles per 2.