# Substitueix la comanda pass pel teu codi
def negatius(a):
    i=0 #defineixo la variable i que anirá recorrent la llista desde el principi fins el final
    j=len(a)-1 #defineixo la variable j que anirá recorrent la llista desde el final fins el principi
    
    while i <= j: #Mentre i sigui més petita o igual que j, és a dir, un cop la i hagi recorregut tota la llista...:
        if a[i]<0: #Si el primer terme a recòrrer es negatiu, deixa'l tal i com està, i pasa la "i" al següent terme de la llista
            i += 1
        else: #Si el terme de la llista a recòrrer es positiu,
            a[i],a[j]= a[j],a[i] #Intercanvia aquest terme pel de la "j", i fes que "j" analitzi el terme posterior
            j -= 1
    return a #Retorna la llista reordenada