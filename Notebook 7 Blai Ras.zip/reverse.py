# Substitueix la comanda pass pel teu codi
def reverse(a): #a serà un string

    #Si aquesta string té 0 o 1 elements, ella mateixa es la versió invertida:
    if len(a) < 2: 
        return a
    
    else:
        #Basanme en l'algoritme de mergesort, divideixo l'string entre dos fins que len(a) < 2:
        
        left = reverse(a[:len(a)/2]) #Formo la "part esquerre" del string
        right = reverse(a[len(a)/2:]) #Formo la "part dreta" del string
        left, right = right, left #Inverteixo els caràcters per cada subdivisió que he creat
        return left + right #Un cop ho he dividit en subproblemes, que corresponen a caràcters invertits, els ajunto suman