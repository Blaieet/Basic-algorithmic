# Substitueix la comanda pass pel teu codi
def length(llista):
    
    if not llista: #Si la llista esta buida, retorna 0, es a dir, la longitud d'una llista buida
        return 0

    else:
        return length(llista[:-1])+1 #Sino, ves restant "1" per cada element de la llista (-1) fins que arribis al final
    