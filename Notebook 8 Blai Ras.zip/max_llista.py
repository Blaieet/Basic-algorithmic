# Substitueix la comanda pass pel teu codi

def max_llista_parametres(a, left, right):
    
    #Creo una funcio amb parametres, on left es l'inici de la llista i right es l'ultima posicio de la llista

    if left == right:
        return a[left]
            
    mid = (left + right) // 2
    
    #Busco el maxim a dreta i a esquerre
    max1 = max_llista_parametres(a,left,mid)
    max2 = max_llista_parametres(a, mid+1,right)
    
    #Busco en quina divisio tinc el numero mes gran
    if max1 > max2:
        return max1 

    else: 
        return max2
    

#Creo max_llista amb nomes un parametre
def max_llista(a):
    return max_llista_parametres(a, 0, len(a)-1)