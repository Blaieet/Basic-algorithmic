# Substitueix la comanda pass pel teu codi
import math

def aprop(a):
    
    # x i y son coordenades dels numeros en cuestió
    x = 0 
    y = 1
    

    realizado = True #variable que comproba si he acabat el proces
    
    #Variables d'inici i final que indiquen per on començar i fins on acabo
    first = 0 
    last = len(a)-1
    
    #Variable que m'indica per on divideixo entre dos, de manera entera
    meitat = (first + last) //2
    
    #Vaig mirant quin número es mes gran que l'altre, i els canvio d'ordre si es aixi. 
    #Ho faig per totes les combinacions posibles
    if a[first] > a[meitat]:
        a[first], a[meitat] = a[meitat], a[first]
        
    if a[first] > a[last]:
        a[first], a[last] = a[last], a[first]
    
    if a[meitat] > a[last]:
        a[meitat], a[last] = a[last], a[meitat]
        
    a[meitat], a[first] = a[first], a[meitat]
    #Sentinella es la variable que em fara de pivot, i la inicialitzo a first, que es zero
    sentinella = first
    
    #Creo "i" i "j" que em recorreran la llista
    i = first+1
    j = last
    
    while realizado:
        
        #Corre la i mentre no trobis un numero mes gran que l'ultim o el element en la posició "i", 
        #sempre i quant sigui mes gran que la sentinella (pivot)
        while i <= last and a[i] <= a[sentinella]:
            
            i+= 1
        
        #Faig el mateix pero per la variable j, que va del reves, desde el final de la llista fins el principi
        while j >= first and a[j] > a[sentinella]:
            j-= 1
        
        #indico que el while acaba quan i es mes gran que j, es a dir, quan recorro tota la llista
        if i >= j:
            realizado = False
        
        else:
            #canvia "i" i "j" si cap de les opcions d'abans s'ha donat
            a[i], a[j] = a[j], a[i]
    
    #El mateix pero amb la sentinella
    a[j], a[sentinella] = a[sentinella], a[j]
    
    #calculo el minim per saber quina es la parella de punts mes a prop
    minim = abs(a[x]-a[y])
    
    #Creo la llista amb el minims, desde x a y 
    llistaminims = a[x:y+1]
    
    
    while x < len(a) and y < len(a):
        
        #Busco el minim mes "minim", es a dir, el mes petit
        if abs(a[x]-a[y]) < minim:
            minim = abs(a[x]-a[y])
            llistaminims = a[x:y+1]
        
        #recorro x i y
        x += 1
        y += 1
        
    #retorno en forma de tupla
    return tuple(llistaminims), "La complexitat d'aquest algorisme es de O(n x logn)"