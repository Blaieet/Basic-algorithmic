# Substitueix la comanda pass pel teu codi
def elimina(a):
    
    first = 0
    
    last = len(a)-1
    
    meitat = (first + last) // 2
    
    realizado = True
    
    if a[first] > a[meitat]:
        a[first], a[meitat] = a[meitat], a[first]
        
    if a[first] > a[last]:
        a[first], a[last] = a[last], a[first]
        
    if a[meitat] > a[last]:
        a[meitat], a[last] = a[last], a[meitat]
        
    a[meitat], a[first] = a[first], a[meitat]
    sentinella =  first
    i = first + 1
    j = last
    
    
    while realizado:
        
        while i <= last and a[i] <= a[sentinella]:
            i+= 1
        
        while j >= first and a[j] > a[sentinella]:
            j-= 1
            
        if i >= j:
            realizado = False
            
        else:
            a[i], a[j] = a[j], a[i]
    
    a[j], a[sentinella] = a[sentinella], a[j]
    
    while last > 0:
        if a[last] == a[last-1]:
            a.remove(a[last])
        last -=1
    return a
        
    