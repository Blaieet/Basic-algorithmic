# Substitueix la comanda pass pel teu codi
def isMember(element,llista):
    
    if not llista: #Si la llista esta buida, voldrá dir que l'element no hi es, per tant, retorna False
        return False
    
    else:
        i = llista.pop() #Anomeno la substitució (.pop()) "i"
        
        if i == element: #Si i es correspon amb l'element que busco, retorna cert, ja que ja he trobat el que buscava
            return True
        
        else:
            return isMember(element, llista) #Sino, crida recursivament la funció fins trobar l'element o fins que es quedi buida