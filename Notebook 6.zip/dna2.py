# Substitueix la comanda pass pel teu codi
# Substitueix el resultat per les teves variables, 
#             pero mantingues el format indicat

import time
def dna2():
    
    archivo = open('HUMAN-DNA.txt','r')
    text = archivo.readlines()
    
    count = 0
    sequencia = "GGCCTTGCCATTGG"
    distancia = []
    patro = []
    t1 = time.clock()
    for linia in text:
        if count >9: break
            
        DistMin = len(linia)
        if len(sequencia) > len(linia):
            sequencia, linia = linia, sequencia
        if len(linia) == 0:
            return len(sequencia)
        first_length = len(sequencia) + 1
        second_length = len(linia) + 1
        distance_matrix = [[0] * second_length for x in range(first_length)]
        for i in range(first_length): distance_matrix[i][0] = 2*i
        for j in range(second_length): distance_matrix[0][j] = 0
        for i in xrange(1, first_length):
            for j in range(1, second_length):
                deletion = distance_matrix[i-1][j] + 2
                insertion = distance_matrix[i][j-1] + 2
                substitution = distance_matrix[i-1][j-1]
                if sequencia[i-1] != linia[j-1]:
                    substitution += 1
                distance_matrix[i][j] = min(insertion,deletion, substitution)
            
        for j in range (second_length):
            
            if distance_matrix[first_length-1][j] < DistMin:
                    DistMin = distance_matrix[first_length-1][j]
                    posicio = j
        distancia.append(DistMin)
        patro.append(linia[(posicio-len(sequencia)-1):posicio])
        count += 1
    archivo.close()
    t2 = time.clock()
    temps = (t2-t1)
    return ([[ 1,distancia[0],patro[0]],
              [ 2,distancia[1],patro[1]],
              [ 3,distancia[2],patro[2]],
              [ 4,distancia[3],patro[3]],
              [ 5,distancia[4],patro[4]],
              [ 6,distancia[5],patro[5]],
              [ 7,distancia[6],patro[6]],
              [ 8,distancia[7],patro[7]],
              [ 9,distancia[8],patro[8]],
              [10,distancia[9],patro[9]]],
                temps)