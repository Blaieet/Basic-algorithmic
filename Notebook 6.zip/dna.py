# Substitueix la comanda pass pel teu codi
# Substitueix el resultat per les teves variables, 
#             pero mantingues el format indicat



#Començo creant l'algorisme de Levenshtein modificat, amb els costos necesaris que m'inidiquen i la fila de 0:


def levenshtein(first, second):
    
    #Si la longitud del primer es major que la del segon, canvial's:
    
    if len(first) > len(second): 
        first, second = second, first
        
    #Si es 0 la longitud del segon, la longitud del primer serà 0:
    
    if len(second) == 0:
        return len(first)


    first_len=len(first) + 1
    second_len = len(second) + 1
    
    #Aqui començo a crear la matriu modificada:
    
    distance_matrix = [[0] * second_len for x in range(first_len)] #Provoco una fila de zeros per saber la distancia:
    
    for i in range(first_len): distance_matrix[i][0] = (2*i) #Com que els costos d'operació són dos, inicialitzaré la matriu 
    #fent 2 * i
    
    for j in range(second_len): distance_matrix[1][j] = j #Creo les columnes
    
    for i in range(1,first_len): #La longitud de la matriu serà desde 1 fins a la longitud de la paraula
        
        for j in range(1, second_len): # La longitud de les columnes, el mateix.
            
            deletion = distance_matrix[i-1][j] + 2  #El cost de "suprimir" és dos, tal i com m'han indicat
            insertion = distance_matrix[i][j-1] + 2 #El cost de inserir una lletra, 2 tambè
            substitution = distance_matrix[i-1][j-1] #Substituir és canviar una lletra del patró amb la paraula que comparem
            # (Fila per columna)
            
            if first[i-1] != second[j-1]: #Si són diferents, el cost de substituir es 1, tal i com m'indiquen
                substitution += 1
            distance_matrix[i][j] = min(insertion, deletion, substitution) #Com que vull saber el cost, agafaré 
            #el mínim de la última columna, que serà el cost final ja que he creat una columna de zeros.

            
    
            
    #Aqui faig les operacions per calcular la distancia d'edició:
    
    MinimaDistancia = second_len #Inicialitzo aquesta variable per cada patró a la longitud d'ell

    for i in range(1, second_len + 1): #Sumo 1 a la longitud del patró per poder calcular la distància sense desbordar els numeros
        if (distance_matrix[first_len-1][second_len - i] < MinimaDistancia): #Si aquesta distancia es mes petita que la matriu formada
            MinimaDistancia = distance_matrix[first_len-1][second_len-i] #La distància serà la longitud del patro i la paraula en l'ultim terme
            
            


    
    
    #Aquest return em retorna MinimaDistancia, que dona la distancia:
    return MinimaDistancia
    
    

def dna():
    archivo = open("HUMAN-DNA.txt","r") #Obre l'arxiu amb el DNA
    
    texto = archivo.readlines() #Llegeix cada línia
    
    archivo.close()
    
    #Estableixo quina seqüencia del DNA vull que es compari per saber la distància, I HI AFEGEIXO LA SEQUENCIA 
    #A CALCULAR ELS 10 PRIMERS SUBSTRINGS SEMBLANTS
    sequencies = ('AGATACATTAGACAATAGAGATGTGGTC','GTCAGTCTGGCCTTGCCATTGGTGCCACCA','TACCGAGAAGCTGGATTACAGCATGTACCATCAT')
    posicio=0 #Em servirà mes endevant per contar la línia

    #Faig aquest proces 3 vegades, 1 per sequencia MES 1 per la sequencia del exercici 2
    for patro in range(3):
        
        t1=time.clock() #El temps que triga a fer tots el patrons començarà aqui

        count = 0 #Count contará cada línia
        
        MinimaDist = 9999 # "MinimaDist es la variable que m'assigna un valor per entrar al if, i que aixi s'actualitzi al seu primer 
        #valor, per tant, li assigno "infinit". Com no tinc infinit, li poso un numero gran: 9999. Estic com inicialitzar
        # una variable a 0, pero fent proces contrari.
        
        for linia in texto: #Per cada linia del text:
            
            distancies = levenshtein(sequencies[patro], linia) #Distancies es una tupla que agafa totes les distàncies 
            # de la sequencia amb cada linia del text, per això crida la funció Levenshtein
            
            if (distancies < MinimaDist): #Si les "distancies" son més petites que MinimaDist (9999)...:
                
                MinimaDist = distancies #MinimaDist serà la distància idònea
                posicio = count
                
            count = count +1 #Ves contant línia per línia
        
        #Com que el count comença a contar desde 0, a la que troba un línia agafa el count de la línia de dalt, per tant, li
        # haig de sumar 1 perquè així agafa la línia de dalt +1 = la línia correcte
        posicioFinal = posicio +1
        
        t2=time.clock() #Aqui deixa de contar el temps
        
        temps = (t2-t1) #Calculo el temps total en segons.
        
        print sequencies[patro], ",", posicioFinal, ",", MinimaDist,"."
    print "en",temps, "segons."
    

